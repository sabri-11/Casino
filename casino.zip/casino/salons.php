<?php
require_once 'auth_check.php';
require_once 'config.php';

$stmt = $pdo->query("SELECT * FROM salons ORDER BY created_at DESC");
$salons = $stmt->fetchAll();

if (empty($salons)) {
    echo "<p>Aucun salon pour le moment.</p>";
} else {
    foreach ($salons as $salon) {
        echo "<div class='salon-box'>";
        echo "<h3>" . htmlspecialchars($salon['game_type']) . "</h3>";
        echo "<p><strong>Nom :</strong> " . htmlspecialchars($salon['name']) . "</p>";
        echo "<p>Joueurs : " . $salon['nb_joueurs'] . "</p>";
        echo "<p>Spectateurs : " . $salon['nb_spectateurs'] . "</p>";
        echo "<p>Max personnes : " . $salon['max_participants'] . "</p>";
        echo "<a href='join_salon.php?id=" . $salon['id'] . "'>Rejoindre</a>";
        echo "</div>";
    }
}
