<?php
require_once 'auth_check.php';
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['salon_name'])) {
    $name = trim($_POST['salon_name']);

    // Insertion dans la table salons
    $stmt = $pdo->prepare("INSERT INTO salons (name, creator_id) VALUES (?, ?)");
    $stmt->execute([$name, $_SESSION['user_id']]);
}

// Redirection vers l'accueil
header("Location: index.php");
exit;
